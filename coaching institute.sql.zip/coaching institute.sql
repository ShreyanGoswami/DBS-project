-- phpMyAdmin SQL Dump
-- version 3.1.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 26, 2015 at 03:04 PM
-- Server version: 5.1.32
-- PHP Version: 5.2.9-1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `coaching institute`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE IF NOT EXISTS `alumni` (
  `S_ID` int(11) NOT NULL,
  `S_name` varchar(20) DEFAULT NULL,
  `Contact` int(11) DEFAULT NULL,
  `Rank` int(11) DEFAULT NULL,
  `Year_passed` int(11) DEFAULT NULL,
  PRIMARY KEY (`S_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alumni`
--


-- --------------------------------------------------------

--
-- Table structure for table `center`
--

CREATE TABLE IF NOT EXISTS `center` (
  `Sec` varchar(3) NOT NULL,
  `C_Address` varchar(50) NOT NULL DEFAULT '',
  `Capacity` int(11) DEFAULT NULL,
  `Contact` int(11) DEFAULT NULL,
  `ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`Sec`,`C_Address`),
  KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `center`
--


-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `C_ID` int(11) NOT NULL,
  `C_name` varchar(10) DEFAULT NULL,
  `C_type` varchar(10) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  PRIMARY KEY (`C_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`C_ID`, `C_name`, `C_type`, `sem`) VALUES
(101, 'Math1', 'ENG', 1),
(103, 'Physics1', 'ENG', 1),
(104, 'Chemistry1', 'ENG', 1),
(102, 'Biology1', 'Medical', 1),
(201, 'Math2', 'ENG', 2);

-- --------------------------------------------------------

--
-- Table structure for table `course_books`
--

CREATE TABLE IF NOT EXISTS `course_books` (
  `Book_ID` int(11) NOT NULL,
  `C_ID` int(11) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `C_type` varchar(10) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  PRIMARY KEY (`Book_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_books`
--


-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE IF NOT EXISTS `exam` (
  `Ex_ID` int(11) NOT NULL,
  `C_ID` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `T_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`Ex_ID`),
  KEY `T_ID` (`T_ID`),
  KEY `C_ID` (`C_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`Ex_ID`, `C_ID`, `Date`, `T_ID`) VALUES
(1011, 101, '2015-04-21', 1),
(1031, 103, '2015-04-22', 2);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE IF NOT EXISTS `result` (
  `Ex_ID` int(11) DEFAULT NULL,
  `S_ID` int(11) DEFAULT NULL,
  `Marks` decimal(5,2) DEFAULT NULL,
  UNIQUE KEY `Ex_ID` (`Ex_ID`,`S_ID`),
  UNIQUE KEY `Ex_ID_2` (`Ex_ID`,`S_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`Ex_ID`, `S_ID`, `Marks`) VALUES
(1011, 1234, '75.00'),
(1011, 1105, '70.00'),
(1031, 1234, '72.00');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `ID` int(11) NOT NULL,
  `Name` varchar(10) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  `Contact` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--


-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `S_ID` int(11) NOT NULL,
  `S_name` varchar(20) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `Contact` int(11) DEFAULT NULL,
  `Email` varchar(20) DEFAULT NULL,
  `C_type` varchar(10) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  PRIMARY KEY (`S_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`S_ID`, `S_name`, `Address`, `DOB`, `Contact`, `Email`, `C_type`, `sem`) VALUES
(1234, 'Rahul', 'Mumbai', '1995-03-14', 997212345, 'abc@gmail.com', 'ENG', 1),
(1108, 'Himanshu', 'Mumbai', '1994-11-24', 991634762, 'himanshu@gmail.com', 'ENG', 1),
(1105, 'Tanisha', 'Delhi', '1995-06-06', 991634762, 'tan@gmail.com', 'ENG', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student_finance`
--

CREATE TABLE IF NOT EXISTS `student_finance` (
  `S_ID` int(11) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `Paid` int(11) DEFAULT NULL,
  UNIQUE KEY `S_ID` (`S_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_finance`
--

INSERT INTO `student_finance` (`S_ID`, `Price`, `Paid`) VALUES
(1234, 40000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_location`
--

CREATE TABLE IF NOT EXISTS `student_location` (
  `S_ID` int(11) DEFAULT NULL,
  `Sec` varchar(3) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  KEY `S_ID` (`S_ID`),
  KEY `Sec` (`Sec`,`Address`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_location`
--

INSERT INTO `student_location` (`S_ID`, `Sec`, `Address`) VALUES
(1234, 'A', 'abc'),
(1108, 'A', 'abc'),
(1105, 'A', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `takes`
--

CREATE TABLE IF NOT EXISTS `takes` (
  `C_ID` int(11) NOT NULL DEFAULT '0',
  `S_ID` int(11) NOT NULL DEFAULT '0',
  `P_F_C` char(1) DEFAULT NULL,
  PRIMARY KEY (`C_ID`,`S_ID`),
  UNIQUE KEY `C_ID` (`C_ID`,`S_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `takes`
--


-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `T_ID` int(11) NOT NULL,
  `T_name` varchar(20) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `contact` varchar(9) DEFAULT NULL,
  `C_Address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`T_ID`),
  KEY `T_ID` (`T_ID`),
  KEY `C_Address` (`C_Address`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`T_ID`, `T_name`, `Address`, `DOB`, `contact`, `C_Address`) VALUES
(1, 'Teacher1', 'def', '1983-05-15', '986407821', 'abc'),
(2, 'Teacher2', 'xyz', '1982-09-30', '954335210', 'abc'),
(3, 'Teacher3', 'rsr', '1981-11-20', '991669450', 'abc'),
(4, 'Teacher4', 'jui', '1980-02-11', '997256149', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_finance`
--

CREATE TABLE IF NOT EXISTS `teacher_finance` (
  `T_ID` int(11) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  `bonus_perc` int(11) DEFAULT NULL,
  UNIQUE KEY `T_ID` (`T_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_finance`
--

INSERT INTO `teacher_finance` (`T_ID`, `salary`, `bonus_perc`) VALUES
(1, 30000, 5),
(2, 40000, 3),
(3, 35000, 4);

-- --------------------------------------------------------

--
-- Table structure for table `teaches`
--

CREATE TABLE IF NOT EXISTS `teaches` (
  `T_ID` int(11) DEFAULT NULL,
  `C_ID` int(11) DEFAULT NULL,
  KEY `T_ID` (`T_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teaches`
--

INSERT INTO `teaches` (`T_ID`, `C_ID`) VALUES
(1, 101),
(2, 103),
(3, 104),
(1, 201);

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE IF NOT EXISTS `timetable` (
  `Day` varchar(10) DEFAULT NULL,
  `Time` time DEFAULT NULL,
  `T_ID` int(11) DEFAULT NULL,
  `Sec` varchar(3) DEFAULT NULL,
  `C_Address` varchar(20) DEFAULT NULL,
  UNIQUE KEY `Day` (`Day`,`Time`,`T_ID`,`Sec`),
  UNIQUE KEY `Day_2` (`Day`,`Time`,`T_ID`,`Sec`),
  UNIQUE KEY `Day_3` (`Day`,`Time`,`T_ID`),
  UNIQUE KEY `Day_4` (`Day`,`Time`,`Sec`),
  KEY `C_Address` (`C_Address`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`Day`, `Time`, `T_ID`, `Sec`, `C_Address`) VALUES
('Monday', '09:00:00', 2, 'A', 'abc'),
('Monday', '16:00:00', 3, 'A', 'abc'),
('Monday', '18:00:00', 1, 'A', 'abc'),
('Teusday', '14:00:00', 2, 'A', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `Uname` varchar(30) NOT NULL,
  `pwd` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`Uname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Uname`, `pwd`) VALUES
('S1234', '1234'),
('S1108', '1108'),
('S1105', '1105'),
('T1', '1111'),
('T2', '2222'),
('T3', '3333'),
('T4', '4444');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `teaches`
--
ALTER TABLE `teaches`
  ADD CONSTRAINT `teaches_ibfk_1` FOREIGN KEY (`T_ID`) REFERENCES `teacher` (`T_ID`);
